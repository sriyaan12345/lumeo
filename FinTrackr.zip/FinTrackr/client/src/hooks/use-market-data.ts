import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export interface LivePrice {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  lastUpdate: string;
}

export function useMarketData() {
  const queryClient = useQueryClient();

  const updatePricesMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/market/update-prices'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
    },
  });

  const getPriceMutation = useMutation({
    mutationFn: ({ symbol, type }: { symbol: string; type: string }) =>
      apiRequest('GET', `/api/market/price/${symbol}?type=${type}`).then(res => res.json()),
  });

  return {
    updateAllPrices: updatePricesMutation.mutate,
    isUpdatingPrices: updatePricesMutation.isPending,
    getPrice: getPriceMutation.mutateAsync,
    isGettingPrice: getPriceMutation.isPending,
  };
}

export function useLivePrice(symbol: string, type: string) {
  const [price, setPrice] = useState<LivePrice | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!symbol) return;

    const fetchPrice = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiRequest('GET', `/api/market/price/${symbol}?type=${type}`);
        const data = await response.json();
        setPrice(data);
      } catch (err) {
        setError('Failed to fetch price data');
        console.error('Price fetch error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPrice();
    
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchPrice, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [symbol, type]);

  return { price, isLoading, error, refetch: () => {} };
}