import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Settings, TrendingUp } from "lucide-react";
import { Subscription, Transaction, Investment } from "@shared/schema";
import { FinancialSummary, CategorySpending, ChartData } from "@/types/financial";
import { formatCurrency, convertCurrency } from "@/lib/currency";
import { LocalStorage } from "@/lib/storage";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Components
import { CurrencySelector } from "@/components/ui/currency-selector";
import { OverviewCards } from "@/components/dashboard/overview-cards";
import { Charts } from "@/components/dashboard/charts";
import { SubscriptionTracker } from "@/components/subscriptions/subscription-tracker";
import { MoneyManager } from "@/components/money/money-manager";
import { InvestmentTracker } from "@/components/investments/investment-tracker";

export default function Dashboard() {
  const [currentCurrency, setCurrentCurrency] = useState(() => LocalStorage.getCurrentCurrency());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: subscriptions = [], isLoading: subscriptionsLoading } = useQuery<Subscription[]>({
    queryKey: ['/api/subscriptions'],
  });

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  const { data: investments = [], isLoading: investmentsLoading } = useQuery<Investment[]>({
    queryKey: ['/api/investments'],
  });

  // Mutations
  const addSubscriptionMutation = useMutation({
    mutationFn: (data: Omit<Subscription, 'id' | 'createdAt'>) => {
      const transformedData = {
        ...data,
        nextPayment: data.nextPayment instanceof Date ? data.nextPayment.toISOString() : data.nextPayment
      };
      return apiRequest('POST', '/api/subscriptions', transformedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/subscriptions'] });
      toast({ title: "Success", description: "Subscription added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add subscription", variant: "destructive" });
    },
  });

  const deleteSubscriptionMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/subscriptions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/subscriptions'] });
      toast({ title: "Success", description: "Subscription deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete subscription", variant: "destructive" });
    },
  });

  const addTransactionMutation = useMutation({
    mutationFn: (data: Omit<Transaction, 'id' | 'createdAt'>) => {
      const transformedData = {
        ...data,
        date: data.date instanceof Date ? data.date.toISOString() : data.date
      };
      return apiRequest('POST', '/api/transactions', transformedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      toast({ title: "Success", description: "Transaction added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add transaction", variant: "destructive" });
    },
  });

  const addInvestmentMutation = useMutation({
    mutationFn: (data: Omit<Investment, 'id' | 'createdAt'>) => {
      const transformedData = {
        ...data,
        purchaseDate: data.purchaseDate instanceof Date ? data.purchaseDate.toISOString() : data.purchaseDate
      };
      return apiRequest('POST', '/api/investments', transformedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
      toast({ title: "Success", description: "Investment added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add investment", variant: "destructive" });
    },
  });

  const updateInvestmentMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<Investment> }) => 
      apiRequest('PUT', `/api/investments/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
      toast({ title: "Success", description: "Investment updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update investment", variant: "destructive" });
    },
  });

  const deleteInvestmentMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/investments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
      toast({ title: "Success", description: "Investment deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete investment", variant: "destructive" });
    },
  });

  // Calculate financial summary
  const calculateSummary = (): FinancialSummary => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const monthlyIncome = transactions
      .filter(t => {
        const transactionDate = new Date(t.date);
        return t.type === 'income' && 
               transactionDate.getMonth() === currentMonth && 
               transactionDate.getFullYear() === currentYear;
      })
      .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

    const monthlyExpenses = transactions
      .filter(t => {
        const transactionDate = new Date(t.date);
        return t.type === 'expense' && 
               transactionDate.getMonth() === currentMonth && 
               transactionDate.getFullYear() === currentYear;
      })
      .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

    const totalInvestments = investments
      .reduce((sum, inv) => {
        const value = parseFloat(inv.shares) * parseFloat(inv.currentPrice);
        return sum + convertCurrency(value, inv.currency, currentCurrency);
      }, 0);

    const totalBalance = monthlyIncome - monthlyExpenses + totalInvestments;

    return {
      totalBalance,
      monthlyIncome,
      monthlyExpenses,
      totalInvestments,
      currency: currentCurrency,
    };
  };

  // Calculate category spending
  const calculateCategorySpending = (): CategorySpending[] => {
    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    const totalExpenses = expenseTransactions.reduce((sum, t) => 
      sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0
    );

    const categoryTotals = expenseTransactions.reduce((acc, t) => {
      const amount = convertCurrency(parseFloat(t.amount), t.currency, currentCurrency);
      acc[t.category] = (acc[t.category] || 0) + amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);
  };

  // Generate chart data
  const generateChartData = (): {
    incomeExpenseData: ChartData;
    investmentData: ChartData;
  } => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    
    // Start with zero data until user adds transactions/investments
    const incomeData = months.map(() => 0);
    const expenseData = months.map(() => 0);
    const investmentValues = months.map(() => 0);

    return {
      incomeExpenseData: {
        labels: months,
        datasets: [
          { label: 'Income', data: incomeData },
          { label: 'Expenses', data: expenseData },
        ],
      },
      investmentData: {
        labels: months,
        datasets: [
          { label: 'Portfolio Value', data: investmentValues },
        ],
      },
    };
  };

  const summary = calculateSummary();
  const categorySpending = calculateCategorySpending();
  const { incomeExpenseData, investmentData } = generateChartData();

  const isLoading = subscriptionsLoading || transactionsLoading || investmentsLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-dots">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Navigation Header */}
      <header className="obsidian-surface backdrop-blur-lg border-b border-border sticky top-0 z-50 cinematic-glow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-primary">
                Lumeo
              </h1>
            </div>
            
            <nav className="hidden md:flex space-x-6 lg:space-x-8">
              <a href="/" className="text-foreground hover:text-primary transition-colors font-medium">
                Dashboard
              </a>
              <a href="/analytics" className="text-muted-foreground hover:text-primary transition-colors">
                Analytics
              </a>
              <a href="#subscriptions" className="text-muted-foreground hover:text-primary transition-colors">
                Subscriptions
              </a>
              <a href="#money" className="text-muted-foreground hover:text-primary transition-colors">
                Money
              </a>
              <a href="#investments" className="text-muted-foreground hover:text-primary transition-colors">
                Investments
              </a>
            </nav>

            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="hidden sm:block">
                <CurrencySelector
                  currentCurrency={currentCurrency}
                  onCurrencyChange={setCurrentCurrency}
                />
              </div>
              <Button variant="ghost" size="sm" onClick={() => window.location.href = '/settings'}>
                <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Dashboard Overview */}
        <section id="dashboard" className="animate-slide-up">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Lumeo Dashboard</h2>
              <p className="text-muted-foreground">Your complete financial overview at a glance</p>
            </div>
          </div>

          <OverviewCards summary={summary} />
          <Charts 
            expenseData={categorySpending}
            incomeExpenseData={incomeExpenseData}
            investmentData={investmentData}
          />
        </section>

        {/* Subscriptions Tracker */}
        <SubscriptionTracker
          subscriptions={subscriptions}
          currency={currentCurrency}
          onAdd={(subscription) => addSubscriptionMutation.mutate(subscription)}
          onDelete={(id) => deleteSubscriptionMutation.mutate(id)}
        />

        {/* Money Manager */}
        <MoneyManager
          transactions={transactions}
          categorySpending={categorySpending}
          currency={currentCurrency}
          onAdd={(transaction) => addTransactionMutation.mutate(transaction)}
        />

        {/* Investment Tracker */}
        <InvestmentTracker
          investments={investments}
          currency={currentCurrency}
          onAdd={(investment) => addInvestmentMutation.mutate(investment)}
          onDelete={(id) => deleteInvestmentMutation.mutate(id)}
          onUpdate={(id, updates) => updateInvestmentMutation.mutate({ id, updates })}
        />

        {/* Quick Actions CTA */}
        <section className="animate-slide-up stagger-9">
          <Card className="lumeo-card rounded-2xl border border-primary/20 shadow-2xl overflow-hidden">
            <CardContent className="p-8 bg-gradient-to-br from-primary/5 to-accent/5">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="mb-6 md:mb-0">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Ready to take control of your finances?</h3>
                  <p className="text-muted-foreground">Add your first transaction or investment to get started with detailed analytics.</p>
                </div>
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                  <Button 
                    className="lumeo-primary hover-lift"
                    data-testid="cta-add-transaction"
                  >
                    Add Transaction
                  </Button>
                  <Button 
                    variant="outline" 
                    className="hover-lift"
                    onClick={() => window.location.href = '/analytics'}
                    data-testid="cta-view-analytics"
                  >
                    View Analytics
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-lg border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-foreground">Lumeo</span>
            </div>
            <p className="text-muted-foreground text-sm">© 2024 Lumeo. All data stored locally on your device.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
