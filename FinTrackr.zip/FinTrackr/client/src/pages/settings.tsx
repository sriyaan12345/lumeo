import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield, 
  Palette, 
  Download,
  Upload,
  Trash2,
  Save,
  Moon,
  Sun,
  Globe,
  Database,
  Zap,
  ArrowLeft
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { LocalStorage } from "@/lib/storage";
import { CURRENCIES } from "@/types/financial";

export default function Settings() {
  const { toast } = useToast();
  const [currentCurrency, setCurrentCurrency] = useState(() => LocalStorage.getCurrentCurrency());
  const [settings, setSettings] = useState({
    // Profile
    name: "",
    
    // Preferences
    currency: currentCurrency,
    language: "en",
    dateFormat: "MM/DD/YYYY",
    numberFormat: "1,234.56",
    
    // Notifications
    emailNotifications: true,
    pushNotifications: false,
    weeklyReports: true,
    budgetAlerts: true,
    subscriptionReminders: true,
    
    // Privacy
    dataSharing: false,
    analytics: true,
    crashReporting: true,
    
    // Display
    darkMode: false,
    animations: true,
    compactView: false,
    showTips: true,
    
    // Budget
    monthlyBudget: 0,
    savingsGoal: 0,
    warningThreshold: 80,
  });

  const handleSave = () => {
    // Save settings to localStorage
    LocalStorage.setCurrentCurrency(settings.currency);
    
    // In a real app, you would save to a database
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const handleExportData = () => {
    // Export user data
    const data = {
      subscriptions: LocalStorage.getSubscriptions(),
      transactions: LocalStorage.getTransactions(),
      investments: LocalStorage.getInvestments(),
      settings: settings,
      exportDate: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lumeo-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Data exported",
      description: "Your financial data has been exported successfully.",
    });
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        
        // Import data (in a real app, you'd validate this more thoroughly)
        if (data.subscriptions) LocalStorage.saveSubscriptions(data.subscriptions);
        if (data.transactions) LocalStorage.saveTransactions(data.transactions);
        if (data.investments) LocalStorage.saveInvestments(data.investments);
        
        toast({
          title: "Data imported",
          description: "Your financial data has been imported successfully.",
        });
      } catch (error) {
        toast({
          title: "Import failed",
          description: "Failed to import data. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
  };

  const handleClearData = () => {
    if (window.confirm("Are you sure you want to clear all data? This action cannot be undone.")) {
      localStorage.clear();
      toast({
        title: "Data cleared",
        description: "All your data has been removed.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="obsidian-surface border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              onClick={() => window.history.back()}
              className="cinematic-glow hover-lift text-moonlight"
              data-testid="back-button"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          </div>
          <div className="text-warp-in">
            <h1 className="text-3xl font-bold text-foreground mb-2">Settings</h1>
            <p className="text-muted-foreground">Manage your preferences and account settings</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="general" className="emerge-from-darkness stagger-1">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="general" className="hover-lift">
              <User className="w-4 h-4 mr-2" />
              General
            </TabsTrigger>
            <TabsTrigger value="notifications" className="hover-lift">
              <Bell className="w-4 h-4 mr-2" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="privacy" className="hover-lift">
              <Shield className="w-4 h-4 mr-2" />
              Privacy
            </TabsTrigger>
            <TabsTrigger value="appearance" className="hover-lift">
              <Palette className="w-4 h-4 mr-2" />
              Appearance
            </TabsTrigger>
            <TabsTrigger value="data" className="hover-lift">
              <Database className="w-4 h-4 mr-2" />
              Data
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="mt-8">
            <div className="space-y-6">
              <Card className="lumeo-card animate-fade-scale stagger-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5 text-lumeo-blue" />
                    Profile Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="name">Display Name</Label>
                    <Input 
                      id="name"
                      value={settings.name}
                      onChange={(e) => setSettings(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter your display name"
                      data-testid="input-name"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="lumeo-card animate-fade-scale stagger-3">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-lumeo-green" />
                    Regional Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="currency">Default Currency</Label>
                      <Select 
                        value={settings.currency} 
                        onValueChange={(value) => setSettings(prev => ({ ...prev, currency: value }))}
                      >
                        <SelectTrigger data-testid="select-currency">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CURRENCIES.map(currency => (
                            <SelectItem key={currency.code} value={currency.code}>
                              {currency.symbol} {currency.code} - {currency.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="language">Language</Label>
                      <Select 
                        value={settings.language}
                        onValueChange={(value) => setSettings(prev => ({ ...prev, language: value }))}
                      >
                        <SelectTrigger data-testid="select-language">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Español</SelectItem>
                          <SelectItem value="fr">Français</SelectItem>
                          <SelectItem value="de">Deutsch</SelectItem>
                          <SelectItem value="zh">中文</SelectItem>
                          <SelectItem value="ja">日本語</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="dateFormat">Date Format</Label>
                      <Select 
                        value={settings.dateFormat}
                        onValueChange={(value) => setSettings(prev => ({ ...prev, dateFormat: value }))}
                      >
                        <SelectTrigger data-testid="select-date-format">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                          <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                          <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="numberFormat">Number Format</Label>
                      <Select 
                        value={settings.numberFormat}
                        onValueChange={(value) => setSettings(prev => ({ ...prev, numberFormat: value }))}
                      >
                        <SelectTrigger data-testid="select-number-format">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1,234.56">1,234.56</SelectItem>
                          <SelectItem value="1.234,56">1.234,56</SelectItem>
                          <SelectItem value="1 234.56">1 234.56</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="lumeo-card animate-fade-scale stagger-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-lumeo-orange" />
                    Budget Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="monthlyBudget">Monthly Budget</Label>
                      <Input 
                        id="monthlyBudget"
                        type="number"
                        value={settings.monthlyBudget}
                        onChange={(e) => setSettings(prev => ({ ...prev, monthlyBudget: Number(e.target.value) }))}
                        data-testid="input-monthly-budget"
                      />
                    </div>
                    <div>
                      <Label htmlFor="savingsGoal">Monthly Savings Goal</Label>
                      <Input 
                        id="savingsGoal"
                        type="number"
                        value={settings.savingsGoal}
                        onChange={(e) => setSettings(prev => ({ ...prev, savingsGoal: Number(e.target.value) }))}
                        data-testid="input-savings-goal"
                      />
                    </div>
                    <div>
                      <Label htmlFor="warningThreshold">Warning Threshold (%)</Label>
                      <Input 
                        id="warningThreshold"
                        type="number"
                        min="0"
                        max="100"
                        value={settings.warningThreshold}
                        onChange={(e) => setSettings(prev => ({ ...prev, warningThreshold: Number(e.target.value) }))}
                        data-testid="input-warning-threshold"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="mt-8">
            <Card className="lumeo-card animate-fade-scale stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-lumeo-purple" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Email Notifications</h4>
                    <p className="text-sm text-muted-foreground">Receive updates via email</p>
                  </div>
                  <Switch 
                    checked={settings.emailNotifications}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, emailNotifications: checked }))}
                    data-testid="switch-email-notifications"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Push Notifications</h4>
                    <p className="text-sm text-muted-foreground">Get notified instantly</p>
                  </div>
                  <Switch 
                    checked={settings.pushNotifications}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, pushNotifications: checked }))}
                    data-testid="switch-push-notifications"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Weekly Reports</h4>
                    <p className="text-sm text-muted-foreground">Summary of your financial activity</p>
                  </div>
                  <Switch 
                    checked={settings.weeklyReports}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, weeklyReports: checked }))}
                    data-testid="switch-weekly-reports"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Budget Alerts</h4>
                    <p className="text-sm text-muted-foreground">When you approach spending limits</p>
                  </div>
                  <Switch 
                    checked={settings.budgetAlerts}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, budgetAlerts: checked }))}
                    data-testid="switch-budget-alerts"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Subscription Reminders</h4>
                    <p className="text-sm text-muted-foreground">Before subscription renewals</p>
                  </div>
                  <Switch 
                    checked={settings.subscriptionReminders}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, subscriptionReminders: checked }))}
                    data-testid="switch-subscription-reminders"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="mt-8">
            <Card className="lumeo-card animate-fade-scale stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-lumeo-red" />
                  Privacy & Security
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Data Sharing</h4>
                    <p className="text-sm text-muted-foreground">Share anonymous usage data to improve Lumeo</p>
                  </div>
                  <Switch 
                    checked={settings.dataSharing}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, dataSharing: checked }))}
                    data-testid="switch-data-sharing"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Analytics</h4>
                    <p className="text-sm text-muted-foreground">Help us understand how you use the app</p>
                  </div>
                  <Switch 
                    checked={settings.analytics}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, analytics: checked }))}
                    data-testid="switch-analytics"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Crash Reporting</h4>
                    <p className="text-sm text-muted-foreground">Automatically send crash reports</p>
                  </div>
                  <Switch 
                    checked={settings.crashReporting}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, crashReporting: checked }))}
                    data-testid="switch-crash-reporting"
                  />
                </div>
                
                <div className="pt-6">
                  <div className="bg-lumeo-blue/5 border border-lumeo-blue/20 rounded-lg p-4">
                    <h5 className="font-medium text-foreground mb-2">Data Security</h5>
                    <p className="text-sm text-muted-foreground">
                      Your financial data is stored locally on your device and never shared with third parties. 
                      All data transmission is encrypted using industry-standard security protocols.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="mt-8">
            <Card className="lumeo-card animate-fade-scale stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="w-5 h-5 text-lumeo-green" />
                  Appearance & Display
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Dark Mode</h4>
                    <p className="text-sm text-muted-foreground">Switch to dark theme</p>
                  </div>
                  <Switch 
                    checked={settings.darkMode}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, darkMode: checked }))}
                    data-testid="switch-dark-mode"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Animations</h4>
                    <p className="text-sm text-muted-foreground">Enable smooth transitions and effects</p>
                  </div>
                  <Switch 
                    checked={settings.animations}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, animations: checked }))}
                    data-testid="switch-animations"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Compact View</h4>
                    <p className="text-sm text-muted-foreground">Show more content in less space</p>
                  </div>
                  <Switch 
                    checked={settings.compactView}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, compactView: checked }))}
                    data-testid="switch-compact-view"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between hover-lift">
                  <div>
                    <h4 className="font-medium text-foreground">Show Tips</h4>
                    <p className="text-sm text-muted-foreground">Display helpful tips and hints</p>
                  </div>
                  <Switch 
                    checked={settings.showTips}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, showTips: checked }))}
                    data-testid="switch-show-tips"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data" className="mt-8">
            <div className="space-y-6">
              <Card className="lumeo-card animate-fade-scale stagger-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="w-5 h-5 text-lumeo-blue" />
                    Data Management
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button 
                      onClick={handleExportData}
                      className="lumeo-primary hover-lift"
                      data-testid="button-export-data"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                    
                    <div>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleImportData}
                        className="hidden"
                        id="import-file"
                      />
                      <Button 
                        onClick={() => document.getElementById('import-file')?.click()}
                        className="lumeo-secondary hover-lift w-full"
                        data-testid="button-import-data"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Import Data
                      </Button>
                    </div>
                    
                    <Button 
                      onClick={handleClearData}
                      variant="destructive"
                      className="hover-lift"
                      data-testid="button-clear-data"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Clear All Data
                    </Button>
                  </div>
                  
                  <div className="bg-lumeo-orange/5 border border-lumeo-orange/20 rounded-lg p-4">
                    <h5 className="font-medium text-foreground mb-2">Data Export</h5>
                    <p className="text-sm text-muted-foreground">
                      Export your data in JSON format for backup or migration purposes. 
                      This includes all your subscriptions, transactions, investments, and settings.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end pt-8 animate-slide-up stagger-5">
          <Button 
            onClick={handleSave}
            className="lumeo-primary hover-lift"
            data-testid="button-save-settings"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>
    </div>
  );
}