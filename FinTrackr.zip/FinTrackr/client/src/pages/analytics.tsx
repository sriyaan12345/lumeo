import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  BarChart3, 
  Calendar,
  Target,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Share,
  ArrowLeft
} from "lucide-react";
import { Subscription, Transaction, Investment } from "@shared/schema";
import { formatCurrency, convertCurrency } from "@/lib/currency";
import { LocalStorage } from "@/lib/storage";
import { AnimatedCounter } from "@/components/ui/animated-counter";

export default function Analytics() {
  const [currentCurrency, setCurrentCurrency] = useState(() => LocalStorage.getCurrentCurrency());
  const [timeRange, setTimeRange] = useState("6months");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Queries
  const { data: subscriptions = [] } = useQuery<Subscription[]>({
    queryKey: ['/api/subscriptions'],
  });

  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  const { data: investments = [] } = useQuery<Investment[]>({
    queryKey: ['/api/investments'],
  });

  // Calculate advanced analytics
  const calculateAdvancedMetrics = () => {
    const now = new Date();
    const monthsBack = timeRange === "6months" ? 6 : timeRange === "1year" ? 12 : 3;
    const startDate = new Date(now.getFullYear(), now.getMonth() - monthsBack, 1);

    const recentTransactions = transactions.filter(t => new Date(t.date) >= startDate);
    
    const totalIncome = recentTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

    const totalExpenses = recentTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

    const savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0;
    
    const monthlyAvgIncome = totalIncome / monthsBack;
    const monthlyAvgExpenses = totalExpenses / monthsBack;
    
    const activeSubscriptions = subscriptions.filter(s => s.isActive === 1);
    const monthlySubscriptionCost = activeSubscriptions.reduce((sum, sub) => {
      const monthlyAmount = sub.billingPeriod === 'yearly' ? 
        parseFloat(sub.amount) / 12 : 
        parseFloat(sub.amount);
      return sum + convertCurrency(monthlyAmount, sub.currency, currentCurrency);
    }, 0);

    const annualSubscriptionCost = monthlySubscriptionCost * 12;
    
    const totalInvestmentValue = investments.reduce((sum, inv) => {
      const value = parseFloat(inv.shares) * parseFloat(inv.currentPrice);
      return sum + convertCurrency(value, inv.currency, currentCurrency);
    }, 0);

    const totalInvested = investments.reduce((sum, inv) => {
      const invested = parseFloat(inv.shares) * parseFloat(inv.purchasePrice);
      return sum + convertCurrency(invested, inv.currency, currentCurrency);
    }, 0);

    const investmentGrowth = totalInvested > 0 ? ((totalInvestmentValue - totalInvested) / totalInvested) * 100 : 0;

    return {
      totalIncome,
      totalExpenses,
      savingsRate,
      monthlyAvgIncome,
      monthlyAvgExpenses,
      monthlySubscriptionCost,
      annualSubscriptionCost,
      totalInvestmentValue,
      totalInvested,
      investmentGrowth,
      netWorth: totalIncome - totalExpenses + totalInvestmentValue
    };
  };

  // Get category breakdown
  const getCategoryBreakdown = () => {
    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    const categoryTotals = expenseTransactions.reduce((acc, t) => {
      const amount = convertCurrency(parseFloat(t.amount), t.currency, currentCurrency);
      acc[t.category] = (acc[t.category] || 0) + amount;
      return acc;
    }, {} as Record<string, number>);

    const totalExpenses = Object.values(categoryTotals).reduce((sum, amount) => sum + amount, 0);

    return Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount);
  };

  // Get spending trends
  const getSpendingTrends = () => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentYear = new Date().getFullYear();
    
    return months.map(month => {
      const monthIndex = months.indexOf(month);
      const monthTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date.getMonth() === monthIndex && date.getFullYear() === currentYear;
      });

      const income = monthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

      const expenses = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + convertCurrency(parseFloat(t.amount), t.currency, currentCurrency), 0);

      return { month, income, expenses, net: income - expenses };
    });
  };

  const metrics = calculateAdvancedMetrics();
  const categoryBreakdown = getCategoryBreakdown();
  const spendingTrends = getSpendingTrends();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="obsidian-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              onClick={() => window.history.back()}
              className="cinematic-glow hover-lift text-moonlight"
              data-testid="back-button"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="text-warp-in">
              <h1 className="text-3xl font-bold text-foreground mb-2">Analytics Dashboard</h1>
              <p className="text-muted-foreground">Deep insights into your financial patterns and performance</p>
            </div>
            
            <div className="flex items-center gap-3 emerge-from-darkness">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-40" data-testid="time-range-selector">
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">Last 3 months</SelectItem>
                  <SelectItem value="6months">Last 6 months</SelectItem>
                  <SelectItem value="1year">Last year</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" className="hover-lift" data-testid="export-data">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              
              <Button variant="outline" className="hover-lift" data-testid="share-analytics">
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="lumeo-card animate-fade-scale stagger-1" data-testid="savings-rate-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-lumeo-green/10 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-lumeo-green" />
                </div>
                <Badge variant={metrics.savingsRate >= 20 ? "default" : "secondary"} className="hover-grow">
                  {metrics.savingsRate >= 20 ? "Excellent" : metrics.savingsRate >= 10 ? "Good" : "Poor"}
                </Badge>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Savings Rate</h3>
              <p className="text-2xl font-bold text-foreground mb-2">
                <AnimatedCounter
                  end={metrics.savingsRate}
                  suffix="%"
                  decimals={1}
                />
              </p>
              <div className="flex items-center text-sm">
                {metrics.savingsRate >= 0 ? (
                  <ArrowUpRight className="w-4 h-4 text-lumeo-green mr-1" />
                ) : (
                  <ArrowDownRight className="w-4 h-4 text-lumeo-red mr-1" />
                )}
                <span className={metrics.savingsRate >= 0 ? 'text-lumeo-green' : 'text-lumeo-red'}>
                  {metrics.savingsRate >= 20 ? 'Above target' : 'Below target'}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="lumeo-card animate-fade-scale stagger-2" data-testid="net-worth-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-lumeo-blue/10 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-lumeo-blue" />
                </div>
                <Badge variant="outline" className="hover-grow">Net Worth</Badge>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Total Net Worth</h3>
              <p className="text-2xl font-bold text-foreground mb-2">
                <AnimatedCounter
                  end={metrics.netWorth}
                  prefix={formatCurrency(0, currentCurrency).replace(/[\d.,]/g, '')}
                  decimals={0}
                />
              </p>
              <div className="flex items-center text-sm">
                <TrendingUp className="w-4 h-4 text-lumeo-green mr-1" />
                <span className="text-lumeo-green">Growing steadily</span>
              </div>
            </CardContent>
          </Card>

          <Card className="lumeo-card animate-fade-scale stagger-3" data-testid="monthly-expenses-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-lumeo-orange/10 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-lumeo-orange" />
                </div>
                <Badge variant="secondary" className="hover-grow">Monthly</Badge>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Avg Monthly Expenses</h3>
              <p className="text-2xl font-bold text-foreground mb-2">
                <AnimatedCounter
                  end={metrics.monthlyAvgExpenses}
                  prefix={formatCurrency(0, currentCurrency).replace(/[\d.,]/g, '')}
                  decimals={0}
                />
              </p>
              <div className="flex items-center text-sm">
                <span className="text-muted-foreground">
                  {formatCurrency(metrics.monthlySubscriptionCost, currentCurrency)} from subscriptions
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="lumeo-card animate-fade-scale stagger-4" data-testid="investment-growth-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-lumeo-purple/10 rounded-xl flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-lumeo-purple" />
                </div>
                <Badge variant={metrics.investmentGrowth >= 0 ? "default" : "destructive"} className="hover-grow">
                  {metrics.investmentGrowth >= 0 ? "Profit" : "Loss"}
                </Badge>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Investment Growth</h3>
              <p className="text-2xl font-bold text-foreground mb-2">
                <AnimatedCounter
                  end={metrics.investmentGrowth}
                  suffix="%"
                  decimals={1}
                />
              </p>
              <div className="flex items-center text-sm">
                {metrics.investmentGrowth >= 0 ? (
                  <ArrowUpRight className="w-4 h-4 text-lumeo-green mr-1" />
                ) : (
                  <ArrowDownRight className="w-4 h-4 text-lumeo-red mr-1" />
                )}
                <span className={metrics.investmentGrowth >= 0 ? 'text-lumeo-green' : 'text-lumeo-red'}>
                  {formatCurrency(metrics.totalInvestmentValue - metrics.totalInvested, currentCurrency)}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="spending" className="animate-slide-up stagger-5">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="spending" className="hover-lift">Spending Analysis</TabsTrigger>
            <TabsTrigger value="trends" className="hover-lift">Trends</TabsTrigger>
            <TabsTrigger value="subscriptions" className="hover-lift">Subscriptions</TabsTrigger>
            <TabsTrigger value="investments" className="hover-lift">Investments</TabsTrigger>
          </TabsList>

          <TabsContent value="spending" className="mt-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Category Breakdown */}
              <Card className="lumeo-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="w-5 h-5 text-lumeo-orange" />
                    Spending by Category
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryBreakdown.slice(0, 8).map((category, index) => (
                      <div key={category.category} className="flex items-center justify-between hover-lift">
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ 
                              backgroundColor: `hsl(${(index * 45) % 360}, 70%, 50%)` 
                            }}
                          />
                          <span className="font-medium text-foreground">{category.category}</span>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">
                            {formatCurrency(category.amount, currentCurrency)}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {category.percentage.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Monthly Comparison */}
              <Card className="lumeo-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-lumeo-blue" />
                    Monthly Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {spendingTrends.slice(-6).map((month, index) => (
                      <div key={month.month} className="hover-lift">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-foreground">{month.month}</span>
                          <span className={`text-sm font-semibold ${
                            month.net >= 0 ? 'text-lumeo-green' : 'text-lumeo-red'
                          }`}>
                            {month.net >= 0 ? '+' : ''}{formatCurrency(month.net, currentCurrency)}
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <div className="flex-1 bg-lumeo-green/20 rounded-full h-2 relative overflow-hidden">
                            <div 
                              className="bg-lumeo-green h-full rounded-full transition-all duration-1000"
                              style={{ 
                                width: `${Math.min((month.income / Math.max(...spendingTrends.map(m => m.income))) * 100, 100)}%` 
                              }}
                            />
                          </div>
                          <div className="flex-1 bg-lumeo-red/20 rounded-full h-2 relative overflow-hidden">
                            <div 
                              className="bg-lumeo-red h-full rounded-full transition-all duration-1000"
                              style={{ 
                                width: `${Math.min((month.expenses / Math.max(...spendingTrends.map(m => m.expenses))) * 100, 100)}%` 
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trends" className="mt-8">
            <Card className="lumeo-card">
              <CardHeader>
                <CardTitle>Financial Trends & Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-lumeo-blue/5 rounded-lg hover-lift">
                    <TrendingUp className="w-8 h-8 text-lumeo-blue mx-auto mb-3" />
                    <h4 className="font-semibold text-foreground mb-2">Income Trend</h4>
                    <p className="text-2xl font-bold text-lumeo-blue mb-1">
                      <AnimatedCounter end={12.5} suffix="%" decimals={1} />
                    </p>
                    <p className="text-sm text-muted-foreground">Growth this quarter</p>
                  </div>
                  
                  <div className="text-center p-6 bg-lumeo-orange/5 rounded-lg hover-lift">
                    <TrendingDown className="w-8 h-8 text-lumeo-orange mx-auto mb-3" />
                    <h4 className="font-semibold text-foreground mb-2">Expense Control</h4>
                    <p className="text-2xl font-bold text-lumeo-orange mb-1">
                      <AnimatedCounter end={8.3} suffix="%" decimals={1} />
                    </p>
                    <p className="text-sm text-muted-foreground">Reduction from last month</p>
                  </div>
                  
                  <div className="text-center p-6 bg-lumeo-green/5 rounded-lg hover-lift">
                    <Target className="w-8 h-8 text-lumeo-green mx-auto mb-3" />
                    <h4 className="font-semibold text-foreground mb-2">Savings Goal</h4>
                    <p className="text-2xl font-bold text-lumeo-green mb-1">
                      <AnimatedCounter end={75} suffix="%" decimals={0} />
                    </p>
                    <p className="text-sm text-muted-foreground">Progress to annual goal</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscriptions" className="mt-8">
            <Card className="lumeo-card">
              <CardHeader>
                <CardTitle>Subscription Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Cost Breakdown</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center hover-lift p-3 rounded-lg bg-muted/30">
                        <span className="text-foreground">Monthly Cost</span>
                        <span className="font-bold text-foreground">
                          {formatCurrency(metrics.monthlySubscriptionCost, currentCurrency)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center hover-lift p-3 rounded-lg bg-muted/30">
                        <span className="text-foreground">Annual Cost</span>
                        <span className="font-bold text-foreground">
                          {formatCurrency(metrics.annualSubscriptionCost, currentCurrency)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center hover-lift p-3 rounded-lg bg-muted/30">
                        <span className="text-foreground">Active Subscriptions</span>
                        <span className="font-bold text-foreground">
                          {subscriptions.filter(s => s.isActive === 1).length}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Optimization Tips</h4>
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg bg-lumeo-blue/5 border border-lumeo-blue/20 hover-lift">
                        <p className="text-sm text-foreground">
                          💡 Consider annual billing to save up to 20% on subscriptions
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-lumeo-orange/5 border border-lumeo-orange/20 hover-lift">
                        <p className="text-sm text-foreground">
                          ⚠️ Review unused subscriptions to reduce monthly costs
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-lumeo-green/5 border border-lumeo-green/20 hover-lift">
                        <p className="text-sm text-foreground">
                          ✨ Your subscription spending is {metrics.monthlySubscriptionCost > 100 ? 'above' : 'within'} average range
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="investments" className="mt-8">
            <Card className="lumeo-card">
              <CardHeader>
                <CardTitle>Investment Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-gradient-to-br from-lumeo-purple/5 to-lumeo-blue/5 rounded-lg hover-lift">
                    <h4 className="font-semibold text-foreground mb-2">Portfolio Value</h4>
                    <p className="text-3xl font-bold text-foreground mb-2">
                      <AnimatedCounter
                        end={metrics.totalInvestmentValue}
                        prefix={formatCurrency(0, currentCurrency).replace(/[\d.,]/g, '')}
                        decimals={0}
                      />
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Total current value
                    </p>
                  </div>
                  
                  <div className="text-center p-6 bg-gradient-to-br from-lumeo-green/5 to-lumeo-blue/5 rounded-lg hover-lift">
                    <h4 className="font-semibold text-foreground mb-2">Total Returns</h4>
                    <p className="text-3xl font-bold text-lumeo-green mb-2">
                      <AnimatedCounter
                        end={metrics.totalInvestmentValue - metrics.totalInvested}
                        prefix={formatCurrency(0, currentCurrency).replace(/[\d.,]/g, '')}
                        decimals={0}
                      />
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {metrics.investmentGrowth.toFixed(1)}% growth
                    </p>
                  </div>
                  
                  <div className="text-center p-6 bg-gradient-to-br from-lumeo-orange/5 to-lumeo-red/5 rounded-lg hover-lift">
                    <h4 className="font-semibold text-foreground mb-2">Diversification</h4>
                    <p className="text-3xl font-bold text-foreground mb-2">
                      {new Set(investments.map(i => i.type)).size}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Asset classes
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}