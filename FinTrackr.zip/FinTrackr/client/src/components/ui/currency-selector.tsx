import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Globe } from "lucide-react";
import { CURRENCIES } from "@/types/financial";
import { LocalStorage } from "@/lib/storage";

interface CurrencySelectorProps {
  currentCurrency: string;
  onCurrencyChange: (currency: string) => void;
}

export function CurrencySelector({ currentCurrency, onCurrencyChange }: CurrencySelectorProps) {
  const handleCurrencyChange = (currency: string) => {
    LocalStorage.setCurrentCurrency(currency);
    onCurrencyChange(currency);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="currency-badge" data-testid="currency-selector">
          <Globe className="w-3 h-3 mr-1" />
          {currentCurrency}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {CURRENCIES.map((currency) => (
          <DropdownMenuItem
            key={currency.code}
            onClick={() => handleCurrencyChange(currency.code)}
            className={currentCurrency === currency.code ? "bg-accent" : ""}
            data-testid={`currency-${currency.code}`}
          >
            <span className="mr-2">{currency.symbol}</span>
            <span className="font-medium">{currency.code}</span>
            <span className="text-muted-foreground ml-2">{currency.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
