import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, ArrowUp, DollarSign, Percent, Trash2, RefreshCw } from "lucide-react";
import { Investment } from "@shared/schema";
import { formatCurrency } from "@/lib/currency";
import { AddInvestmentForm } from "./add-investment-form";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { useMarketData } from "@/hooks/use-market-data";
import { useToast } from "@/hooks/use-toast";
import { LivePriceIndicator } from "./live-price-indicator";
import { EditableField } from "@/components/ui/editable-field";

interface InvestmentTrackerProps {
  investments: Investment[];
  currency: string;
  onAdd: (investment: Omit<Investment, 'id' | 'createdAt'>) => void;
  onDelete: (id: string) => void;
  onUpdate?: (id: string, updates: Partial<Investment>) => void;
}

export function InvestmentTracker({ investments, currency, onAdd, onDelete, onUpdate }: InvestmentTrackerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { updateAllPrices, isUpdatingPrices } = useMarketData();
  const { toast } = useToast();

  const totalValue = investments.reduce((sum, inv) => 
    sum + (parseFloat(inv.shares) * parseFloat(inv.currentPrice)), 0
  );

  const totalInvested = investments.reduce((sum, inv) => 
    sum + (parseFloat(inv.shares) * parseFloat(inv.purchasePrice)), 0
  );

  const totalGain = totalValue - totalInvested;
  const todaysGain = totalValue * 0.0154; // Mock today's gain percentage
  const annualReturn = totalInvested > 0 ? ((totalGain / totalInvested) * 100) : 0;

  const getInvestmentColor = (type: string) => {
    const colors: Record<string, string> = {
      'Stock': 'bg-blue-500',
      'ETF': 'bg-orange-500',
      'Mutual Fund': 'bg-green-500',
      'Bond': 'bg-purple-500',
      'Cryptocurrency': 'bg-yellow-500',
      'Real Estate': 'bg-indigo-500',
      'Commodity': 'bg-red-500',
      'Other': 'bg-gray-500',
    };
    return colors[type] || 'bg-gray-500';
  };

  const getGainLossColor = (gain: number) => {
    return gain >= 0 ? 'text-secondary' : 'text-destructive';
  };

  const calculateGainLoss = (investment: Investment) => {
    const currentValue = parseFloat(investment.shares) * parseFloat(investment.currentPrice);
    const purchaseValue = parseFloat(investment.shares) * parseFloat(investment.purchasePrice);
    const gain = currentValue - purchaseValue;
    const percentage = purchaseValue > 0 ? ((gain / purchaseValue) * 100) : 0;
    return { gain, percentage };
  };

  return (
    <section id="investments" className="animate-slide-up stagger-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Investment Portfolio</h2>
          <p className="text-muted-foreground">Monitor your investment performance and growth</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
          <Button
            onClick={() => {
              updateAllPrices();
              toast({ title: "Updating prices...", description: "Fetching latest market data" });
            }}
            disabled={isUpdatingPrices}
            variant="outline"
            className="shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isUpdatingPrices ? 'animate-spin' : ''}`} />
            Update Prices
          </Button>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="lumeo-accent shadow-lg hover:shadow-xl transition-all duration-300"
                data-testid="add-investment-button"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Investment
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
            <AddInvestmentForm
              currency={currency}
              onSubmit={(investment) => {
                onAdd({
                  ...investment,
                  currency: investment.currency || currency
                });
                setIsAddDialogOpen(false);
              }}
              onCancel={() => setIsAddDialogOpen(false)}
            />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-lg border border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-muted-foreground">Total Value</h4>
              <TrendingUp className="w-4 h-4 text-secondary" />
            </div>
            <p className="text-2xl font-bold text-foreground" data-testid="total-investment-value">
              <AnimatedCounter
                end={totalValue}
                prefix={formatCurrency(0, currency).replace(/[\d.,]/g, '')}
                decimals={2}
              />
            </p>
            <p className="text-sm text-secondary">
              {annualReturn >= 0 ? '+' : ''}{annualReturn.toFixed(1)}% this year
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-muted-foreground">Today's Gain</h4>
              <ArrowUp className="w-4 h-4 text-secondary" />
            </div>
            <p className="text-2xl font-bold text-foreground" data-testid="todays-gain">
              <AnimatedCounter
                end={todaysGain}
                prefix={formatCurrency(0, currency).replace(/[\d.,]/g, '')}
                decimals={2}
              />
            </p>
            <p className="text-sm text-secondary">+1.54%</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-muted-foreground">Total Invested</h4>
              <DollarSign className="w-4 h-4 text-primary" />
            </div>
            <p className="text-2xl font-bold text-foreground" data-testid="total-invested">
              <AnimatedCounter
                end={totalInvested}
                prefix={formatCurrency(0, currency).replace(/[\d.,]/g, '')}
                decimals={2}
              />
            </p>
            <p className="text-sm text-muted-foreground">Principal amount</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg border border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-muted-foreground">Annual Return</h4>
              <Percent className="w-4 h-4 text-accent" />
            </div>
            <p className="text-2xl font-bold text-foreground" data-testid="annual-return">
              <AnimatedCounter
                end={annualReturn}
                suffix="%"
                decimals={1}
              />
            </p>
            <p className="text-sm text-secondary">Above average</p>
          </CardContent>
        </Card>
      </div>

      {/* Holdings */}
      <Card className="shadow-lg border border-border">
        <CardHeader className="border-b border-border">
          <CardTitle className="text-lg font-semibold">Your Holdings</CardTitle>
        </CardHeader>
        
        <CardContent className="p-6">
          {investments.length === 0 ? (
            <div className="text-center py-12" data-testid="empty-investments">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">No investments yet</h3>
              <p className="text-muted-foreground mb-4">Add your first investment to start tracking your portfolio performance.</p>
              <Button 
                onClick={() => setIsAddDialogOpen(true)}
                className="lumeo-accent hover-lift"
                data-testid="add-first-investment"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Investment
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {investments.map((investment, index) => {
                const { gain, percentage } = calculateGainLoss(investment);
                const currentValue = parseFloat(investment.shares) * parseFloat(investment.currentPrice);
                
                return (
                  <div 
                    key={investment.id} 
                    className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-all duration-300 hover-lift"
                    data-testid={`investment-item-${index}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 ${getInvestmentColor(investment.type)} rounded-lg flex items-center justify-center text-white font-bold text-sm`}>
                        {investment.symbol}
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{investment.name}</h4>
                        <div className="flex items-center space-x-2">
                          <p className="text-sm text-muted-foreground">
                            {parseFloat(investment.shares).toFixed(2)} shares
                          </p>
                          <Badge variant="secondary" className="text-xs">
                            {investment.type}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-semibold text-foreground" data-testid={`investment-value-${index}`}>
                          {formatCurrency(currentValue, investment.currency)}
                        </p>
                        <p className={`text-sm font-medium ${getGainLossColor(gain)}`} data-testid={`investment-gain-${index}`}>
                          {gain >= 0 ? '+' : ''}{formatCurrency(gain, investment.currency)} ({percentage.toFixed(1)}%)
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(investment.id)}
                        className="text-destructive hover:text-destructive/80 hover:bg-destructive/10"
                        data-testid={`delete-investment-${index}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
