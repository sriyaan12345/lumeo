import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import { useLivePrice } from '@/hooks/use-market-data';
import { formatCurrency } from '@/lib/currency';

interface LivePriceIndicatorProps {
  symbol: string;
  type: string;
  currency: string;
  currentPrice: string;
  onPriceUpdate?: (newPrice: number) => void;
}

export function LivePriceIndicator({ 
  symbol, 
  type, 
  currency, 
  currentPrice,
  onPriceUpdate 
}: LivePriceIndicatorProps) {
  const { price, isLoading, refetch } = useLivePrice(symbol, type);
  const [showLivePrice, setShowLivePrice] = useState(false);

  useEffect(() => {
    if (price && onPriceUpdate) {
      onPriceUpdate(price.price);
    }
  }, [price, onPriceUpdate]);

  const isGain = price ? price.changePercent >= 0 : false;
  const priceToShow = showLivePrice && price ? price.price : parseFloat(currentPrice);

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm">
        <span className="font-semibold">
          {formatCurrency(priceToShow, currency)}
        </span>
        {price && showLivePrice && (
          <div className="flex items-center gap-1 mt-1">
            {isGain ? (
              <TrendingUp className="w-3 h-3 text-green-500" />
            ) : (
              <TrendingDown className="w-3 h-3 text-red-500" />
            )}
            <span className={`text-xs ${isGain ? 'text-green-500' : 'text-red-500'}`}>
              {isGain ? '+' : ''}{price.changePercent.toFixed(2)}%
            </span>
          </div>
        )}
      </div>
      
      <Button
        size="sm"
        variant="ghost"
        onClick={() => {
          setShowLivePrice(!showLivePrice);
          if (!showLivePrice) {
            refetch();
          }
        }}
        disabled={isLoading}
        className="h-6 w-6 p-0"
      >
        <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
      </Button>
      
      {price && showLivePrice && (
        <Badge variant="outline" className="text-xs">
          Live
        </Badge>
      )}
    </div>
  );
}