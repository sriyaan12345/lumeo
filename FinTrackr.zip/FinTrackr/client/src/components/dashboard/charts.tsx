import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoreHorizontal } from "lucide-react";
import Chart from "chart.js/auto";
import { ChartData, CategorySpending } from "@/types/financial";
import { chartColors, doughnutChartOptions, barChartOptions, lineChartOptions } from "@/lib/chart-config";

interface ChartsProps {
  expenseData: CategorySpending[];
  incomeExpenseData: ChartData;
  investmentData: ChartData;
}

export function Charts({ expenseData, incomeExpenseData, investmentData }: ChartsProps) {
  const expenseChartRef = useRef<HTMLCanvasElement>(null);
  const incomeExpenseChartRef = useRef<HTMLCanvasElement>(null);
  const investmentChartRef = useRef<HTMLCanvasElement>(null);
  
  const expenseChartInstance = useRef<Chart | null>(null);
  const incomeExpenseChartInstance = useRef<Chart | null>(null);
  const investmentChartInstance = useRef<Chart | null>(null);

  // Expense Breakdown Chart
  useEffect(() => {
    if (!expenseChartRef.current) return;

    // Destroy previous chart
    if (expenseChartInstance.current) {
      expenseChartInstance.current.destroy();
    }

    const ctx = expenseChartRef.current.getContext('2d');
    if (!ctx) return;

    const colors = [
      chartColors.orange,
      chartColors.primary,
      chartColors.purple,
      chartColors.success,
      chartColors.pink,
    ];

    expenseChartInstance.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: expenseData.map(item => item.category),
        datasets: [{
          data: expenseData.map(item => item.amount),
          backgroundColor: colors.slice(0, expenseData.length),
          borderWidth: 0,
        }]
      },
      options: doughnutChartOptions,
    });

    return () => {
      if (expenseChartInstance.current) {
        expenseChartInstance.current.destroy();
      }
    };
  }, [expenseData]);

  // Income vs Expenses Chart
  useEffect(() => {
    if (!incomeExpenseChartRef.current) return;

    if (incomeExpenseChartInstance.current) {
      incomeExpenseChartInstance.current.destroy();
    }

    const ctx = incomeExpenseChartRef.current.getContext('2d');
    if (!ctx) return;

    incomeExpenseChartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: incomeExpenseData.labels,
        datasets: [
          {
            label: 'Income',
            data: incomeExpenseData.datasets[0]?.data || [],
            backgroundColor: 'rgba(34, 197, 94, 0.8)',
            borderColor: chartColors.success,
            borderWidth: 2,
            borderRadius: 8,
          },
          {
            label: 'Expenses',
            data: incomeExpenseData.datasets[1]?.data || [],
            backgroundColor: 'rgba(239, 68, 68, 0.8)',
            borderColor: chartColors.danger,
            borderWidth: 2,
            borderRadius: 8,
          }
        ]
      },
      options: barChartOptions,
    });

    return () => {
      if (incomeExpenseChartInstance.current) {
        incomeExpenseChartInstance.current.destroy();
      }
    };
  }, [incomeExpenseData]);

  // Investment Performance Chart
  useEffect(() => {
    if (!investmentChartRef.current) return;

    if (investmentChartInstance.current) {
      investmentChartInstance.current.destroy();
    }

    const ctx = investmentChartRef.current.getContext('2d');
    if (!ctx) return;

    investmentChartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: investmentData.labels,
        datasets: [{
          label: 'Portfolio Value',
          data: investmentData.datasets[0]?.data || [],
          borderColor: chartColors.accent,
          backgroundColor: 'rgba(139, 92, 246, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: chartColors.accent,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 6,
        }]
      },
      options: lineChartOptions,
    });

    return () => {
      if (investmentChartInstance.current) {
        investmentChartInstance.current.destroy();
      }
    };
  }, [investmentData]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Expense Chart */}
      <Card className="animate-fade-scale stagger-4 border border-border shadow-lg" data-testid="expense-chart">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Expense Breakdown</CardTitle>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="chart-container">
            <canvas ref={expenseChartRef}></canvas>
          </div>
        </CardContent>
      </Card>

      {/* Income vs Expenses Chart */}
      <Card className="animate-fade-scale stagger-5 border border-border shadow-lg" data-testid="income-expense-chart">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Income vs Expenses</CardTitle>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="chart-container">
            <canvas ref={incomeExpenseChartRef}></canvas>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
