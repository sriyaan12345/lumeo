import { Card, CardContent } from "@/components/ui/card";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { formatCurrency } from "@/lib/currency";
import { FinancialSummary } from "@/types/financial";
import { DollarSign, TrendingUp, TrendingDown, PieChart } from "lucide-react";

interface OverviewCardsProps {
  summary: FinancialSummary;
}

export function OverviewCards({ summary }: OverviewCardsProps) {
  const cards = [
    {
      title: "Total Balance",
      value: summary.totalBalance,
      change: "0%",
      changeType: "positive",
      icon: DollarSign,
      color: "bg-lumeo-green text-white",
      delay: "stagger-1",
    },
    {
      title: "Monthly Income",
      value: summary.monthlyIncome,
      change: "0%",
      changeType: "positive",
      icon: TrendingUp,
      color: "bg-lumeo-blue text-white",
      delay: "stagger-2",
    },
    {
      title: "Monthly Expenses",
      value: summary.monthlyExpenses,
      change: "0%",
      changeType: "negative",
      icon: TrendingDown,
      color: "bg-lumeo-red text-white",
      delay: "stagger-3",
    },
    {
      title: "Investments",
      value: summary.totalInvestments,
      change: "0%",
      changeType: "positive",
      icon: PieChart,
      color: "bg-lumeo-purple text-white",
      delay: "stagger-4",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card 
            key={card.title} 
            className={`card-hover animate-fade-scale ${card.delay} border border-border shadow-lg`}
            data-testid={`overview-card-${index}`}
          >
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center hover-grow`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className={`text-xs font-semibold ${
                  card.changeType === 'positive' ? 'text-secondary' : 'text-destructive'
                }`}>
                  {card.change}
                </span>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">
                {card.title}
              </h3>
              <p className="text-2xl font-bold text-foreground" data-testid={`card-value-${index}`}>
                <AnimatedCounter
                  end={card.value}
                  prefix={formatCurrency(0, summary.currency).replace(/[\d.,]/g, '')}
                  decimals={2}
                />
              </p>
              <div className="mt-4 w-full bg-muted rounded-full h-2 progress-bar">
                <div 
                  className={`${card.color.split(' ')[0]} h-2 rounded-full transition-all duration-1000 ease-out`}
                  style={{ 
                    width: `${Math.min(Math.max((card.value / 25000) * 100, 15), 85)}%`
                  }}
                ></div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
