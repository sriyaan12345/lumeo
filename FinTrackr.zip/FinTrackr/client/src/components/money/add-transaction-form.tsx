import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { insertTransactionSchema } from "@shared/schema";
import { TRANSACTION_CATEGORIES } from "@/types/financial";
import { z } from "zod";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";

const formSchema = insertTransactionSchema.extend({
  date: z.date({
    required_error: "Transaction date is required",
  }),
});

type FormData = z.infer<typeof formSchema>;

interface AddTransactionFormProps {
  type: 'income' | 'expense';
  currency: string;
  onSubmit: (transaction: FormData) => void;
  onCancel: () => void;
}

export function AddTransactionForm({ type, currency, onSubmit, onCancel }: AddTransactionFormProps) {
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type,
      amount: "0",
      currency,
      category: type === 'income' ? "Salary" : "Other",
      description: "",
      date: new Date(),
    },
  });

  const handleSubmit = (data: FormData) => {
    onSubmit(data);
  };

  const getCategories = () => {
    if (type === 'income') {
      return ['Salary', 'Freelance', 'Investment', 'Business', 'Gift', 'Other'];
    }
    return TRANSACTION_CATEGORIES;
  };

  return (
    <>
      <DialogHeader>
        <DialogTitle>
          Add New {type === 'income' ? 'Income' : 'Expense'}
        </DialogTitle>
        <DialogDescription>
          {type === 'income' ? 'Record money coming in from various sources.' : 'Track your spending and expense categories.'}
        </DialogDescription>
      </DialogHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01" 
                      placeholder="100.00" 
                      {...field} 
                      data-testid="input-transaction-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-transaction-category">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {getCategories().map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder={type === 'income' ? 'Monthly salary payment' : 'Grocery shopping at supermarket'} 
                    {...field} 
                    data-testid="input-transaction-description"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className="justify-start text-left font-normal"
                        data-testid="input-transaction-date"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {field.value ? format(field.value, "PPP") : "Pick a date"}
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end space-x-2 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
              data-testid="button-cancel-transaction"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className={type === 'income' ? 'lumeo-secondary hover-lift' : 'lumeo-danger hover-lift'} 
              data-testid="button-submit-transaction"
            >
              Add {type === 'income' ? 'Income' : 'Expense'}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
}
