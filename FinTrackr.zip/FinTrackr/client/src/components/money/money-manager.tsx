import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Minus, DollarSign, ShoppingCart, Zap, Briefcase } from "lucide-react";
import { Transaction } from "@shared/schema";
import { formatCurrency } from "@/lib/currency";
import { CategorySpending } from "@/types/financial";
import { AddTransactionForm } from "./add-transaction-form";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

interface MoneyManagerProps {
  transactions: Transaction[];
  categorySpending: CategorySpending[];
  currency: string;
  onAdd: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
}

export function MoneyManager({ transactions, categorySpending, currency, onAdd }: MoneyManagerProps) {
  const [isAddIncomeOpen, setIsAddIncomeOpen] = useState(false);
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");

  const filteredTransactions = categoryFilter === "all" ? 
    transactions : 
    transactions.filter(t => t.category === categoryFilter);

  const sortedTransactions = [...filteredTransactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10);

  const getTransactionIcon = (category: string, type: string) => {
    if (type === 'income') {
      return category === 'Salary' ? DollarSign : Briefcase;
    }
    
    const icons: Record<string, any> = {
      'Food & Dining': ShoppingCart,
      'Transportation': Zap,
      'Shopping': ShoppingCart,
      'Utilities': Zap,
      'Entertainment': ShoppingCart,
    };
    return icons[category] || ShoppingCart;
  };

  const getTransactionColor = (type: string) => {
    return type === 'income' ? 
      'from-green-500 to-emerald-400' : 
      'from-orange-500 to-red-500';
  };

  return (
    <section id="money" className="animate-slide-up stagger-7">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Money Manager</h2>
          <p className="text-muted-foreground">Track your income and expenses efficiently</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Dialog open={isAddIncomeOpen} onOpenChange={setIsAddIncomeOpen}>
            <DialogTrigger asChild>
              <Button 
                className="lumeo-secondary shadow-lg hover:shadow-xl transition-all duration-300 hover-lift"
                data-testid="add-income-button"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Income
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <AddTransactionForm
                type="income"
                currency={currency}
                onSubmit={(transaction) => {
                  onAdd(transaction);
                  setIsAddIncomeOpen(false);
                }}
                onCancel={() => setIsAddIncomeOpen(false)}
              />
            </DialogContent>
          </Dialog>

          <Dialog open={isAddExpenseOpen} onOpenChange={setIsAddExpenseOpen}>
            <DialogTrigger asChild>
              <Button 
                className="lumeo-danger shadow-lg hover:shadow-xl transition-all duration-300 hover-lift"
                data-testid="add-expense-button"
              >
                <Minus className="w-4 h-4 mr-2" />
                Add Expense
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <AddTransactionForm
                type="expense"
                currency={currency}
                onSubmit={(transaction) => {
                  onAdd(transaction);
                  setIsAddExpenseOpen(false);
                }}
                onCancel={() => setIsAddExpenseOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions */}
        <Card className="lg:col-span-2 shadow-lg border border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48" data-testid="category-filter">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Food & Dining">Food & Dining</SelectItem>
                  <SelectItem value="Transportation">Transportation</SelectItem>
                  <SelectItem value="Shopping">Shopping</SelectItem>
                  <SelectItem value="Utilities">Utilities</SelectItem>
                  <SelectItem value="Entertainment">Entertainment</SelectItem>
                  <SelectItem value="Salary">Salary</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            {sortedTransactions.length === 0 ? (
              <div className="text-center py-12" data-testid="empty-transactions">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">No transactions yet</h3>
                <p className="text-muted-foreground mb-4">Start tracking your income and expenses to see your financial overview.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sortedTransactions.map((transaction, index) => {
                  const Icon = getTransactionIcon(transaction.category, transaction.type);
                  return (
                    <div 
                      key={transaction.id} 
                      className="flex items-center justify-between p-4 hover:bg-muted/50 rounded-lg transition-colors"
                      data-testid={`transaction-item-${index}`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 ${transaction.type === 'income' ? 'bg-lumeo-green' : 'bg-lumeo-orange'} rounded-lg flex items-center justify-center hover-grow`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{transaction.description}</h4>
                          <div className="flex items-center space-x-2">
                            <p className="text-sm text-muted-foreground">
                              {new Date(transaction.date).toLocaleDateString()}
                            </p>
                            <Badge variant="secondary" className="text-xs">
                              {transaction.category}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${
                          transaction.type === 'income' ? 'text-secondary' : 'text-destructive'
                        }`} data-testid={`transaction-amount-${index}`}>
                          {transaction.type === 'income' ? '+' : '-'}
                          {formatCurrency(parseFloat(transaction.amount), transaction.currency)}
                        </p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {transaction.type}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Categories Overview */}
        <Card className="shadow-lg border border-border">
          <CardHeader className="border-b border-border">
            <CardTitle className="text-lg font-semibold">Spending by Category</CardTitle>
          </CardHeader>
          
          <CardContent className="p-6">
            {categorySpending.length === 0 ? (
              <div className="text-center py-8" data-testid="empty-categories">
                <p className="text-muted-foreground">No expense data available</p>
              </div>
            ) : (
              <div className="space-y-6">
                {categorySpending.map((category, index) => (
                  <div key={category.category} data-testid={`category-item-${index}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-foreground">{category.category}</span>
                      <span className="text-sm font-semibold text-foreground" data-testid={`category-amount-${index}`}>
                        {formatCurrency(category.amount, currency)}
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2 progress-bar">
                      <div 
                        className={`h-2 rounded-full transition-all duration-1000 ease-out ${
                          index % 4 === 0 ? 'bg-lumeo-orange' :
                          index % 4 === 1 ? 'bg-lumeo-blue' :
                          index % 4 === 2 ? 'bg-lumeo-purple' :
                          'bg-lumeo-green'
                        }`}
                        style={{ width: `${Math.min(category.percentage, 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1" data-testid={`category-percentage-${index}`}>
                      {category.percentage.toFixed(0)}% of expenses
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
