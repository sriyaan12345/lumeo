import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2 } from "lucide-react";
import { Subscription } from "@shared/schema";
import { formatCurrency } from "@/lib/currency";
import { AddSubscriptionForm } from "./add-subscription-form";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

interface SubscriptionTrackerProps {
  subscriptions: Subscription[];
  currency: string;
  onAdd: (subscription: Omit<Subscription, 'id' | 'createdAt'>) => void;
  onDelete: (id: string) => void;
}

export function SubscriptionTracker({ subscriptions, currency, onAdd, onDelete }: SubscriptionTrackerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const totalMonthlyCost = subscriptions
    .filter(sub => sub.isActive === 1)
    .reduce((sum, sub) => {
      const monthlyAmount = sub.billingPeriod === 'yearly' ? 
        parseFloat(sub.amount) / 12 : 
        parseFloat(sub.amount);
      return sum + monthlyAmount;
    }, 0);

  const activeSubscriptions = subscriptions.filter(sub => sub.isActive === 1);
  
  const nextPayment = subscriptions
    .filter(sub => sub.isActive === 1)
    .sort((a, b) => new Date(a.nextPayment).getTime() - new Date(b.nextPayment).getTime())[0];

  const getSubscriptionIcon = (category: string) => {
    const categoryIcons: Record<string, string> = {
      'Streaming': '🎬',
      'Music': '🎵',
      'Software': '💻',
      'Gaming': '🎮',
      'Productivity': '⚡',
      'Cloud Storage': '☁️',
      'Design': '🎨',
      'Development': '👨‍💻',
      'Other': '📱',
    };
    return categoryIcons[category] || '📱';
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Streaming': 'bg-red-500',
      'Music': 'bg-green-500',
      'Software': 'bg-red-600',
      'Gaming': 'bg-gray-800',
      'Productivity': 'bg-blue-500',
      'Cloud Storage': 'bg-sky-500',
      'Design': 'bg-purple-500',
      'Development': 'bg-orange-500',
      'Other': 'bg-gray-500',
    };
    return colors[category] || 'bg-gray-500';
  };

  return (
    <section id="subscriptions" className="animate-slide-up stagger-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Subscription Tracker</h2>
          <p className="text-muted-foreground">Manage all your recurring subscriptions</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="mt-4 md:mt-0 lumeo-primary shadow-lg hover:shadow-xl transition-all duration-300 hover-lift"
              data-testid="add-subscription-button"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Subscription
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <AddSubscriptionForm
              currency={currency}
              onSubmit={(subscription) => {
                onAdd(subscription);
                setIsAddDialogOpen(false);
              }}
              onCancel={() => setIsAddDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-lg border border-border overflow-hidden">
        <CardContent className="p-6 border-b border-border">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 rounded-lg">
              <h4 className="text-sm font-medium text-muted-foreground mb-1">Total Monthly Cost</h4>
              <p className="text-2xl font-bold text-red-600" data-testid="total-monthly-cost">
                {formatCurrency(totalMonthlyCost, currency)}
              </p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg">
              <h4 className="text-sm font-medium text-muted-foreground mb-1">Active Subscriptions</h4>
              <p className="text-2xl font-bold text-blue-600" data-testid="active-subscriptions">
                {activeSubscriptions.length}
              </p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg">
              <h4 className="text-sm font-medium text-muted-foreground mb-1">Next Payment</h4>
              <p className="text-lg font-bold text-green-600" data-testid="next-payment">
                {nextPayment ? new Date(nextPayment.nextPayment).toLocaleDateString() : 'None'}
              </p>
            </div>
          </div>
        </CardContent>

        <CardContent className="p-6">
          {subscriptions.length === 0 ? (
            <div className="text-center py-12" data-testid="empty-subscriptions">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💳</span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">No subscriptions yet</h3>
              <p className="text-muted-foreground mb-4">Add your first subscription to start tracking your recurring expenses.</p>
              <Button 
                onClick={() => setIsAddDialogOpen(true)}
                className="lumeo-primary hover-lift"
                data-testid="add-first-subscription"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Subscription
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((subscription, index) => (
                <div 
                  key={subscription.id} 
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
                  data-testid={`subscription-item-${index}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 ${getCategoryColor(subscription.category)} rounded-lg flex items-center justify-center text-white font-bold text-xl`}>
                      {getSubscriptionIcon(subscription.category)}
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{subscription.name}</h4>
                      <div className="flex items-center space-x-2">
                        <p className="text-sm text-muted-foreground">{subscription.provider}</p>
                        <Badge variant="secondary" className="text-xs">
                          {subscription.category}
                        </Badge>
                        {subscription.isActive === 0 && (
                          <Badge variant="destructive" className="text-xs">
                            Inactive
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="font-semibold text-foreground" data-testid={`subscription-amount-${index}`}>
                        {formatCurrency(parseFloat(subscription.amount), subscription.currency)}
                      </p>
                      <p className="text-sm text-muted-foreground capitalize">
                        {subscription.billingPeriod}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(subscription.id)}
                      className="text-destructive hover:text-destructive/80 hover:bg-destructive/10"
                      data-testid={`delete-subscription-${index}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
