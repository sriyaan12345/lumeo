import { Subscription, Transaction, Investment } from "@shared/schema";

const STORAGE_KEYS = {
  SUBSCRIPTIONS: 'financeflow_subscriptions',
  TRANSACTIONS: 'financeflow_transactions',
  INVESTMENTS: 'financeflow_investments',
  CURRENCY: 'financeflow_currency',
} as const;

export class LocalStorage {
  static getSubscriptions(): Subscription[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SUBSCRIPTIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static saveSubscriptions(subscriptions: Subscription[]): void {
    localStorage.setItem(STORAGE_KEYS.SUBSCRIPTIONS, JSON.stringify(subscriptions));
  }

  static getTransactions(): Transaction[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static saveTransactions(transactions: Transaction[]): void {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }

  static getInvestments(): Investment[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.INVESTMENTS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static saveInvestments(investments: Investment[]): void {
    localStorage.setItem(STORAGE_KEYS.INVESTMENTS, JSON.stringify(investments));
  }

  static getCurrentCurrency(): string {
    return localStorage.getItem(STORAGE_KEYS.CURRENCY) || 'USD';
  }

  static setCurrentCurrency(currency: string): void {
    localStorage.setItem(STORAGE_KEYS.CURRENCY, currency);
  }
}
