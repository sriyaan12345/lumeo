import { ChartData } from '@/types/financial';

export const chartColors = {
  primary: 'rgb(59, 130, 246)',
  secondary: 'rgb(16, 185, 129)',
  accent: 'rgb(139, 92, 246)',
  danger: 'rgb(239, 68, 68)',
  warning: 'rgb(245, 158, 11)',
  success: 'rgb(34, 197, 94)',
  orange: 'rgb(251, 146, 60)',
  pink: 'rgb(236, 72, 153)',
  indigo: 'rgb(99, 102, 241)',
  emerald: 'rgb(52, 211, 153)',
  purple: 'rgb(168, 85, 247)',
};

export const defaultChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: {
        padding: 20,
        usePointStyle: true,
      },
    },
  },
  animation: {
    duration: 2000,
    easing: 'easeInOutQuart' as const,
  },
};

export const doughnutChartOptions = {
  ...defaultChartOptions,
  cutout: '70%',
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins.legend,
      position: 'bottom' as const,
    },
  },
};

export const barChartOptions = {
  ...defaultChartOptions,
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
    },
    x: {
      grid: {
        display: false,
      },
    },
  },
};

export const lineChartOptions = {
  ...defaultChartOptions,
  scales: {
    y: {
      beginAtZero: false,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
    },
    x: {
      grid: {
        display: false,
      },
    },
  },
};
