export interface FinancialSummary {
  totalBalance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  totalInvestments: number;
  currency: string;
}

export interface CategorySpending {
  category: string;
  amount: number;
  percentage: number;
  budget?: number;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string;
    borderWidth?: number;
    fill?: boolean;
    tension?: number;
  }[];
}

export interface CurrencyRate {
  code: string;
  name: string;
  symbol: string;
  rate: number;
}

export const CURRENCIES: CurrencyRate[] = [
  // Major Currencies
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1 },
  { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.85 },
  { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.73 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rate: 110 },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'Fr', rate: 0.92 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', rate: 1.25 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', rate: 1.35 },
  { code: 'NZD', name: 'New Zealand Dollar', symbol: 'NZ$', rate: 1.42 },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', rate: 1.34 },
  { code: 'HKD', name: 'Hong Kong Dollar', symbol: 'HK$', rate: 7.82 },
  
  // Asian Currencies
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rate: 7.25 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', rate: 83.12 },
  { code: 'KRW', name: 'South Korean Won', symbol: '₩', rate: 1328.5 },
  { code: 'THB', name: 'Thai Baht', symbol: '฿', rate: 35.85 },
  { code: 'MYR', name: 'Malaysian Ringgit', symbol: 'RM', rate: 4.68 },
  { code: 'IDR', name: 'Indonesian Rupiah', symbol: 'Rp', rate: 15420 },
  { code: 'PHP', name: 'Philippine Peso', symbol: '₱', rate: 56.25 },
  { code: 'VND', name: 'Vietnamese Dong', symbol: '₫', rate: 24385 },
  { code: 'TWD', name: 'Taiwan Dollar', symbol: 'NT$', rate: 31.45 },
  
  // European Currencies
  { code: 'NOK', name: 'Norwegian Krone', symbol: 'kr', rate: 10.85 },
  { code: 'SEK', name: 'Swedish Krona', symbol: 'kr', rate: 10.92 },
  { code: 'DKK', name: 'Danish Krone', symbol: 'kr', rate: 6.84 },
  { code: 'PLN', name: 'Polish Zloty', symbol: 'zł', rate: 4.02 },
  { code: 'CZK', name: 'Czech Koruna', symbol: 'Kč', rate: 22.85 },
  { code: 'HUF', name: 'Hungarian Forint', symbol: 'Ft', rate: 364.2 },
  { code: 'RON', name: 'Romanian Leu', symbol: 'lei', rate: 4.68 },
  { code: 'BGN', name: 'Bulgarian Lev', symbol: 'лв', rate: 1.81 },
  { code: 'HRK', name: 'Croatian Kuna', symbol: 'kn', rate: 6.98 },
  { code: 'RSD', name: 'Serbian Dinar', symbol: 'din', rate: 107.2 },
  
  // Middle East & Africa
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', rate: 3.67 },
  { code: 'SAR', name: 'Saudi Riyal', symbol: 'ر.س', rate: 3.75 },
  { code: 'QAR', name: 'Qatari Riyal', symbol: 'ر.ق', rate: 3.64 },
  { code: 'KWD', name: 'Kuwaiti Dinar', symbol: 'د.ك', rate: 0.31 },
  { code: 'BHD', name: 'Bahraini Dinar', symbol: '.د.ب', rate: 0.38 },
  { code: 'OMR', name: 'Omani Rial', symbol: 'ر.ع.', rate: 0.38 },
  { code: 'JOD', name: 'Jordanian Dinar', symbol: 'د.ا', rate: 0.71 },
  { code: 'LBP', name: 'Lebanese Pound', symbol: 'ل.ل', rate: 15000 },
  { code: 'EGP', name: 'Egyptian Pound', symbol: 'ج.م', rate: 30.85 },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R', rate: 18.65 },
  { code: 'NGN', name: 'Nigerian Naira', symbol: '₦', rate: 1545 },
  { code: 'KES', name: 'Kenyan Shilling', symbol: 'Sh', rate: 155.2 },
  { code: 'GHS', name: 'Ghanaian Cedi', symbol: '₵', rate: 15.85 },
  
  // Latin America
  { code: 'BRL', name: 'Brazilian Real', symbol: 'R$', rate: 5.14 },
  { code: 'MXN', name: 'Mexican Peso', symbol: '$', rate: 16.85 },
  { code: 'ARS', name: 'Argentine Peso', symbol: '$', rate: 1028.5 },
  { code: 'CLP', name: 'Chilean Peso', symbol: '$', rate: 965.8 },
  { code: 'COP', name: 'Colombian Peso', symbol: '$', rate: 4285.5 },
  { code: 'PEN', name: 'Peruvian Sol', symbol: 'S/', rate: 3.78 },
  { code: 'UYU', name: 'Uruguayan Peso', symbol: '$', rate: 42.85 },
  { code: 'BOB', name: 'Bolivian Boliviano', symbol: 'Bs', rate: 6.91 },
  { code: 'PYG', name: 'Paraguayan Guarani', symbol: '₲', rate: 7485 },
  
  // Crypto & Digital
  { code: 'BTC', name: 'Bitcoin', symbol: '₿', rate: 0.000023 },
  { code: 'ETH', name: 'Ethereum', symbol: 'Ξ', rate: 0.00042 },
  
  // Other Major
  { code: 'RUB', name: 'Russian Ruble', symbol: '₽', rate: 92.45 },
  { code: 'TRY', name: 'Turkish Lira', symbol: '₺', rate: 33.25 },
  { code: 'ILS', name: 'Israeli Shekel', symbol: '₪', rate: 3.68 },
];

export const SUBSCRIPTION_CATEGORIES = [
  'Streaming',
  'Music',
  'Software',
  'Gaming',
  'Productivity',
  'Cloud Storage',
  'Design',
  'Development',
  'Other'
] as const;

export const TRANSACTION_CATEGORIES = [
  'Food & Dining',
  'Transportation',
  'Shopping',
  'Utilities',
  'Entertainment',
  'Healthcare',
  'Education',
  'Travel',
  'Gifts',
  'Other'
] as const;

export const INVESTMENT_TYPES = [
  'Stock',
  'ETF',
  'Mutual Fund',
  'Bond',
  'Cryptocurrency',
  'Real Estate',
  'Commodity',
  'Other'
] as const;
