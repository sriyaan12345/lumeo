import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSubscriptionSchema, insertTransactionSchema, insertInvestmentSchema } from "@shared/schema";
import { marketDataService } from "./services/market-data";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Subscriptions routes
  app.get("/api/subscriptions", async (req, res) => {
    try {
      const subscriptions = await storage.getSubscriptions();
      res.json(subscriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get subscriptions" });
    }
  });

  app.post("/api/subscriptions", async (req, res) => {
    try {
      const data = insertSubscriptionSchema.parse(req.body);
      const subscription = await storage.createSubscription(data);
      res.json(subscription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid subscription data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create subscription" });
      }
    }
  });

  app.delete("/api/subscriptions/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSubscription(req.params.id);
      if (deleted) {
        res.json({ message: "Subscription deleted" });
      } else {
        res.status(404).json({ message: "Subscription not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete subscription" });
    }
  });

  // Transactions routes
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const data = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(data);
      res.json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create transaction" });
      }
    }
  });

  app.delete("/api/transactions/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTransaction(req.params.id);
      if (deleted) {
        res.json({ message: "Transaction deleted" });
      } else {
        res.status(404).json({ message: "Transaction not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // Investments routes
  app.get("/api/investments", async (req, res) => {
    try {
      const investments = await storage.getInvestments();
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get investments" });
    }
  });

  app.post("/api/investments", async (req, res) => {
    try {
      const data = insertInvestmentSchema.parse(req.body);
      const investment = await storage.createInvestment(data);
      res.json(investment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid investment data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create investment" });
      }
    }
  });

  app.put("/api/investments/:id", async (req, res) => {
    try {
      const updated = await storage.updateInvestment(req.params.id, req.body);
      if (updated) {
        res.json(updated);
      } else {
        res.status(404).json({ message: "Investment not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to update investment" });
    }
  });

  app.delete("/api/investments/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteInvestment(req.params.id);
      if (deleted) {
        res.json({ message: "Investment deleted" });
      } else {
        res.status(404).json({ message: "Investment not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete investment" });
    }
  });

  // Live market data routes
  app.get("/api/market/price/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const { type = 'stock' } = req.query;
      const price = await marketDataService.getPrice(symbol, type as string);
      
      if (price) {
        res.json(price);
      } else {
        res.status(404).json({ message: "Price data not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch price data" });
    }
  });

  app.post("/api/market/update-prices", async (req, res) => {
    try {
      const investments = await storage.getInvestments();
      const investmentSymbols = investments.map(inv => ({ symbol: inv.symbol, type: inv.type }));
      const priceMap = await marketDataService.updateMultiplePrices(investmentSymbols);
      
      // Update current prices in storage
      for (const investment of investments) {
        const livePrice = priceMap.get(investment.symbol);
        if (livePrice) {
          investment.currentPrice = livePrice.price.toString();
          await storage.updateInvestment(investment.id, investment);
        }
      }
      
      res.json({ updated: priceMap.size, total: investments.length });
    } catch (error) {
      res.status(500).json({ message: "Failed to update prices" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
