import axios from 'axios';

export interface LivePrice {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  lastUpdate: string;
}

export class MarketDataService {
  private readonly API_KEY = '2KE0JCPAMIXUIBXA';
  private readonly BASE_URL = 'https://www.alphavantage.co/query';
  
  async getStockPrice(symbol: string): Promise<LivePrice | null> {
    try {
      const response = await axios.get(this.BASE_URL, {
        params: {
          function: 'GLOBAL_QUOTE',
          symbol: symbol,
          apikey: this.API_KEY
        },
        timeout: 10000
      });

      const quote = response.data['Global Quote'];
      if (!quote || !quote['05. price']) {
        console.warn(`No data found for symbol: ${symbol}`);
        return null;
      }

      return {
        symbol: quote['01. symbol'],
        price: parseFloat(quote['05. price']),
        change: parseFloat(quote['09. change']),
        changePercent: parseFloat(quote['10. change percent'].replace('%', '')),
        lastUpdate: quote['07. latest trading day']
      };
    } catch (error) {
      console.error(`Error fetching price for ${symbol}:`, error);
      return null;
    }
  }

  async getCryptoPrice(symbol: string): Promise<LivePrice | null> {
    try {
      const response = await axios.get(this.BASE_URL, {
        params: {
          function: 'DIGITAL_CURRENCY_DAILY',
          symbol: symbol,
          market: 'USD',
          apikey: this.API_KEY
        },
        timeout: 10000
      });

      const timeSeries = response.data['Time Series (Digital Currency Daily)'];
      if (!timeSeries) {
        console.warn(`No crypto data found for symbol: ${symbol}`);
        return null;
      }

      const latestDate = Object.keys(timeSeries)[0];
      const latestData = timeSeries[latestDate];
      
      const currentPrice = parseFloat(latestData['4a. close (USD)']);
      const openPrice = parseFloat(latestData['1a. open (USD)']);
      const change = currentPrice - openPrice;
      const changePercent = (change / openPrice) * 100;

      return {
        symbol: symbol,
        price: currentPrice,
        change: change,
        changePercent: changePercent,
        lastUpdate: latestDate
      };
    } catch (error) {
      console.error(`Error fetching crypto price for ${symbol}:`, error);
      return null;
    }
  }

  async getPrice(symbol: string, type: string): Promise<LivePrice | null> {
    if (type.toLowerCase() === 'cryptocurrency' || type.toLowerCase() === 'crypto') {
      return this.getCryptoPrice(symbol);
    } else {
      return this.getStockPrice(symbol);
    }
  }

  async updateMultiplePrices(investments: Array<{symbol: string; type: string}>): Promise<Map<string, LivePrice>> {
    const priceMap = new Map<string, LivePrice>();
    
    // Process in batches to respect API rate limits
    const batchSize = 5;
    for (let i = 0; i < investments.length; i += batchSize) {
      const batch = investments.slice(i, i + batchSize);
      const promises = batch.map(async (inv) => {
        const price = await this.getPrice(inv.symbol, inv.type);
        if (price) {
          priceMap.set(inv.symbol, price);
        }
        // Add delay between API calls to respect rate limits
        await new Promise(resolve => setTimeout(resolve, 200));
      });
      
      await Promise.all(promises);
    }
    
    return priceMap;
  }
}

export const marketDataService = new MarketDataService();