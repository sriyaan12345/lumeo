# FinanceFlow - Personal Finance Dashboard

## Overview

FinanceFlow is a comprehensive personal finance management application built with React and Express. The app provides users with tools to track subscriptions, manage transactions, monitor investments, and visualize financial data through interactive charts. It features a modern, responsive design using shadcn/ui components and supports multiple currencies.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The client-side application is built using React 18 with TypeScript, featuring:

- **Component Library**: shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: React Query (TanStack Query) for server state management
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Charts**: Chart.js for data visualization
- **Routing**: Wouter for client-side routing

### Backend Architecture

The server is built with Express.js and TypeScript:

- **API Design**: RESTful API endpoints for CRUD operations on financial data
- **Storage Layer**: Abstracted storage interface with in-memory implementation (MemStorage)
- **Data Validation**: Zod schemas for runtime type checking
- **Development Tools**: Vite for hot module replacement and development server

### Data Storage Solutions

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Three main entities - subscriptions, transactions, and investments
- **Migrations**: Drizzle-kit for database schema management
- **Local Storage**: Client-side storage for user preferences like currency settings

### Component Structure

The UI is organized into feature-based modules:

- **Dashboard**: Main overview with financial summary and charts
- **Subscriptions**: Recurring payment tracking and management
- **Money Management**: Income and expense transaction handling
- **Investments**: Portfolio tracking with gain/loss calculations
- **UI Components**: Reusable shadcn/ui components with custom enhancements

### Data Flow

- Client components use React Query for data fetching and caching
- Forms validate data using Zod schemas before submission
- API endpoints handle CRUD operations and return JSON responses
- Charts dynamically update based on filtered and aggregated data

## External Dependencies

### Core Framework Dependencies

- **React 18**: Frontend framework with hooks and context
- **Express.js**: Backend web server framework
- **TypeScript**: Type safety across the entire codebase
- **Vite**: Build tool and development server

### Database and ORM

- **PostgreSQL**: Primary database (configured via DATABASE_URL)
- **Drizzle ORM**: Type-safe database operations and migrations
- **@neondatabase/serverless**: PostgreSQL connection driver

### UI and Styling

- **shadcn/ui**: Component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Accessible component primitives
- **Chart.js**: Canvas-based charting library for data visualization

### Form Handling and Validation

- **React Hook Form**: Performant form library
- **Zod**: Runtime schema validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### State Management and Data Fetching

- **TanStack React Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing

### Development and Build Tools

- **ESBuild**: Fast JavaScript bundler for production builds
- **tsx**: TypeScript execution for development
- **PostCSS**: CSS post-processing for Tailwind